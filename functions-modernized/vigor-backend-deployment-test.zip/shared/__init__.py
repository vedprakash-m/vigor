# Shared modules for Vigor Azure Functions
