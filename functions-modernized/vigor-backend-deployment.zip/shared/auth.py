"""
Authentication module for Vigor Functions
JWT token validation and user authentication for Azure Functions
"""

import jwt
import json
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import azure.functions as func

from config import get_settings

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Custom authentication error"""
    pass


async def get_current_user_from_token(req: func.HttpRequest) -> Optional[Dict[str, Any]]:
    """Extract and validate user from JWT token in request"""
    try:
        settings = get_settings()
        
        # Get token from Authorization header
        auth_header = req.headers.get("Authorization")
        if not auth_header:
            return None
        
        # Extract token (format: "Bearer <token>")
        if not auth_header.startswith("Bearer "):
            return None
        
        token = auth_header[7:]  # Remove "Bearer " prefix
        
        # Decode and validate JWT token
        try:
            payload = jwt.decode(
                token,
                settings.JWT_SECRET_KEY,
                algorithms=["HS256"]
            )
            
            # Check token expiration
            exp = payload.get("exp")
            if exp and datetime.fromtimestamp(exp, tz=timezone.utc) < datetime.now(timezone.utc):
                logger.warning("Token has expired")
                return None
            
            # Extract user information
            user_data = {
                "user_id": payload.get("sub") or payload.get("user_id"),
                "email": payload.get("email"),
                "username": payload.get("username"),
                "tier": payload.get("tier", "free"),
                "exp": exp
            }
            
            # Validate required fields
            if not user_data["user_id"]:
                logger.warning("Token missing required user_id")
                return None
            
            return user_data
            
        except jwt.ExpiredSignatureError:
            logger.warning("JWT token has expired")
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f"Invalid JWT token: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error decoding JWT token: {str(e)}")
            return None
            
    except Exception as e:
        logger.error(f"Error in get_current_user_from_token: {str(e)}")
        return None


async def require_admin_user(req: func.HttpRequest) -> Optional[Dict[str, Any]]:
    """Require admin user authentication"""
    try:
        user = await get_current_user_from_token(req)
        if not user:
            return None
        
        # Check if user has admin privileges
        if user.get("tier") != "admin":
            logger.warning(f"Non-admin user attempted admin access: {user.get('user_id')}")
            return None
        
        return user
        
    except Exception as e:
        logger.error(f"Error in require_admin_user: {str(e)}")
        return None


async def validate_azure_entra_token(token: str) -> Optional[Dict[str, Any]]:
    """Validate Azure Entra ID token (for future integration)"""
    try:
        # This would integrate with Azure Entra ID token validation
        # For now, return None to use JWT validation
        logger.info("Azure Entra ID validation not yet implemented")
        return None
        
    except Exception as e:
        logger.error(f"Error validating Azure Entra token: {str(e)}")
        return None


def create_access_token(user_data: Dict[str, Any], expires_delta: Optional[int] = None) -> str:
    """Create JWT access token for user"""
    try:
        settings = get_settings()
        
        # Set expiration (default: 24 hours)
        if expires_delta is None:
            expires_delta = 24 * 60 * 60  # 24 hours in seconds
        
        exp = datetime.now(timezone.utc).timestamp() + expires_delta
        
        # Create payload
        payload = {
            "sub": user_data["user_id"],
            "user_id": user_data["user_id"],
            "email": user_data.get("email"),
            "username": user_data.get("username"),
            "tier": user_data.get("tier", "free"),
            "iat": datetime.now(timezone.utc).timestamp(),
            "exp": exp
        }
        
        # Encode token
        token = jwt.encode(
            payload,
            settings.JWT_SECRET_KEY,
            algorithm="HS256"
        )
        
        return token
        
    except Exception as e:
        logger.error(f"Error creating access token: {str(e)}")
        raise AuthenticationError(f"Failed to create access token: {str(e)}")


def hash_password(password: str) -> str:
    """Hash password using bcrypt (for user registration)"""
    try:
        import bcrypt
        
        # Generate salt and hash password
        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password.encode('utf-8'), salt)
        
        return password_hash.decode('utf-8')
        
    except ImportError:
        logger.error("bcrypt not available, using simple hash")
        # Fallback to simple hash (not recommended for production)
        import hashlib
        return hashlib.sha256(password.encode()).hexdigest()
    except Exception as e:
        logger.error(f"Error hashing password: {str(e)}")
        raise AuthenticationError(f"Failed to hash password: {str(e)}")


def verify_password(password: str, password_hash: str) -> bool:
    """Verify password against hash"""
    try:
        import bcrypt
        
        return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))
        
    except ImportError:
        # Fallback for simple hash
        import hashlib
        return hashlib.sha256(password.encode()).hexdigest() == password_hash
    except Exception as e:
        logger.error(f"Error verifying password: {str(e)}")
        return False


def extract_user_from_request(req: func.HttpRequest) -> Optional[Dict[str, Any]]:
    """Extract user info from request headers or body for registration/login"""
    try:
        # Try to get from request body first
        try:
            body = req.get_json()
            if body and isinstance(body, dict):
                return body
        except Exception:
            pass
        
        # Try to get from form data
        try:
            form_data = {}
            for key, value in req.form.items():
                form_data[key] = value
            if form_data:
                return form_data
        except Exception:
            pass
        
        return None
        
    except Exception as e:
        logger.error(f"Error extracting user from request: {str(e)}")
        return None


# Rate limiting helpers
_rate_limit_cache = {}

def check_rate_limit(key: str, limit: int, window: int) -> bool:
    """Simple in-memory rate limiting"""
    try:
        now = datetime.now(timezone.utc).timestamp()
        
        if key not in _rate_limit_cache:
            _rate_limit_cache[key] = []
        
        # Clean old entries
        _rate_limit_cache[key] = [
            timestamp for timestamp in _rate_limit_cache[key]
            if now - timestamp < window
        ]
        
        # Check limit
        if len(_rate_limit_cache[key]) >= limit:
            return False
        
        # Add current request
        _rate_limit_cache[key].append(now)
        return True
        
    except Exception as e:
        logger.error(f"Error in rate limiting: {str(e)}")
        return True  # Allow request if rate limiting fails
