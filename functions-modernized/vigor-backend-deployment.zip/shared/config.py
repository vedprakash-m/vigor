"""
Configuration management for Vigor Functions
Centralized settings using Pydantic Settings
"""

import os
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Cosmos DB Configuration
    COSMOS_DB_ENDPOINT: str = Field(default="", description="Cosmos DB endpoint URL")
    COSMOS_DB_KEY: str = Field(default="", description="Cosmos DB primary key")
    COSMOS_DB_DATABASE: str = Field(default="vigor_db", description="Database name")
    COSMOS_DB_DATABASE_NAME: str = Field(default="vigor_db", description="Database name (alias)")
    
    # Admin Configuration
    ADMIN_EMAIL: str = Field(default="admin@vigor.com", description="Default admin email")
    ADMIN_PASSWORD: str = Field(default="ChangeMe123!", description="Default admin password")
    
    # AI Configuration (Single Provider)
    AI_PROVIDER: str = Field(default="gemini-flash-2.5", description="AI provider")
    GOOGLE_AI_API_KEY: str = Field(default="", description="Google Gemini API key")
    AI_MONTHLY_BUDGET: str = Field(default="50", description="Monthly AI budget")
    AI_COST_THRESHOLD: str = Field(default="40", description="Daily cost threshold")
    
    # Authentication
    JWT_SECRET_KEY: str = Field(default="", description="JWT secret key")
    AZURE_TENANT_ID: str = Field(default="VED", description="Azure tenant ID")
    AZURE_DOMAIN_ID: str = Field(default="vedid.onmicrosoft.com", description="Azure domain")
    
    # Application Settings
    ENVIRONMENT: str = Field(default="development", description="Environment")
    LOG_LEVEL: str = Field(default="INFO", description="Logging level")
    
    # Rate Limiting
    RATE_LIMIT_STORAGE_TYPE: str = Field(default="memory", description="Rate limit storage")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# Global settings instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton pattern)"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings() -> Settings:
    """Force reload settings from environment"""
    global _settings
    _settings = Settings()
    return _settings
